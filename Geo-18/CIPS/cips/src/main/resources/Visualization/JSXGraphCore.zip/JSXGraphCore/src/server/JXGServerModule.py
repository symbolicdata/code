import JXG

class JXGServerModule(object):

    def __init__(self):
        self.isJXGServerModule = True

	def init(self, resp):
		return
